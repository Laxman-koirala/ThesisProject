from django.apps import AppConfig


class CredentialConfig(AppConfig):
    name = 'credential'
